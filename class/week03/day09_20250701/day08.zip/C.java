package day08;

import java.util.*;

import soo.P;

public class C {
	Hashtable h = new Hashtable();
	void in() {
		h.put(new Integer(1), "봄");
		h.put(new Integer(2), "여름");
		h.put(new Integer(3), "가을");
		h.put(new Integer(4), "겨울");
		h.put(new Integer(5), "가을");
	}
	void out() {
		Enumeration e = h.keys();
		while(e.hasMoreElements()) {
			Object keyObj = e.nextElement();
			Object valObj = h.get(keyObj);
			Integer key = (Integer)keyObj;
			String val = (String)valObj;
			P.pln("key: " + key + ", value: " + val);
		}
	}
	public static void main(String[] args) {
		C c = new C();
		c.in(); c.out();
	}
}
