class C1 {
	byte b;
	short s;
	char c;
	int i;
	long lo;
	float f;
	double d;
	boolean flag;
	String str;

	void m1() {
		byte b = 1;
		short s = 2;
		int r = b + s;
	}

	void m2() {
		pln("b: " + b);
		pln("s: " + s);
		pln("c: " + (int) c);
		pln("i: " + i);
		pln("lo: " + lo);
		pln("f: " + f);
		pln("d: " + d);
		pln("flag: " + flag);
		pln("str: " + str);
	}
	void m3() {
		pln("Integer.MAX_VALUE: " + Integer.MAX_VALUE);
		pln("Integer.MIN_VALUE: " + Integer.MIN_VALUE);
	}
	void pln(String str) {
		System.out.println(str);
	}

	public static void main(String[] args) {
		C1 c = new C1();
		// c.m1();
		c.m2();
		c.m3();
	}
}

class C2 {
	byte b;
	short s;
	char c;
	int i;
	long lo;
	float f;
	double d;
	boolean flag;
	String str;

	void m1() {
		byte b = 1;
		short s = 2;
		int r = b + s;
	}

	void m2() {
		pln("b: " + b);
		pln("s: " + s);
		pln("c: " + (int)c);
		pln("i: " + i);
		pln("lo: " + lo);
		pln("f: " + f);
		pln("d: " + d);
		pln("flag: " + flag);
		pln("str: " + str);
	}

	void m3() {
		pln("Integer.MAX_VALUE: " + Integer.MAX_VALUE);
		pln("Integer.MIN_VALUE: " + Integer.MIN_VALUE);
	}
	void pln(String str) {
		System.out.println(str);
	}
	
	public static void main(String[] args) {
		C2 c = new C2();
		// c.m1();
		c.m2();
		c.m3();
	}
}

class C3 {
	byte b;
	short s;
	char c;
	int i;
	long lo;
	float f;
	double d;
	boolean flag;
	String str;

	void m1() {
		byte b = 1;
		short s = 2;
		int r = b + s;
	}
	void m2() {
		pln("b: " + b);
		pln("s: " + s);
		pln("c: " + (int) c);
		pln("i: " + i);
		pln("lo: " + lo);
		pln("f: " + f);
		pln("d: " + d);
		pln("flag: " + flag);
		pln("str: " + str);
	}
	void m3() {
		pln("Integer.MAX_VALUE: " + Integer.MAX_VALUE);
		pln("Integer.MIN_VALUE: " + Integer.MIN_VALUE);
	}
	void pln(String str) {
		System.out.println(str);
	}
	public static void main(String[] args) {
		C3 c = new C3();
		// c.m1();
		c.m2();
		c.m3();
	}
}

class C4 {
	byte b;
	short s;
	char c;
	int i;
	long lo;
	float f;
	double d;
	boolean flag;
	String str;

	void m1() {
		byte b = 1;
		short s = 2;
		int r = b + s;
	}

	void m2() {
		pln("b: " + b);
		pln("s: " + s);
		pln("c: " + (int) c);
		pln("i: " + i);
		pln("lo:" + lo);
		pln("f: " + f);
		pln("d: " + d);
		pln("flag: " + flag);
		pln("str: " + str);
	}
	void m3() {
		pln("Integer.MAX_VALUE: " + Integer.MAX_VALUE);
		pln("Integer.MIN_VALUE: " + Integer.MIN_VALUE);
	}

	void pln(String str) {
		System.out.println(str);
	}

	public static void main(String[] args) {
		C4 c = new C4();
		// c.m1();
		c.m2();
		c.m3();
	}
}

class C5 {
	byte b;
	short s;
	char c;
	int i;
	long lo;
	float f;
	double d;
	boolean flag;
	String str;

	void m1() {
		byte b = 1;
		short s = 2;
		int r = b + s;
	}

	void m2() {
		pln("b: " + b);
		pln("s: " + s);
		pln("c: " + (int) c);
		pln("i: " + i);
		pln("lo: " + lo);
		pln("f: " + f);
		pln("d: " + d);
		pln("flag: " + flag);
		pln("str: " + str);
	}
	
	void m3() {
		pln("Integer.MAX_VALUE: " + Integer.MAX_VALUE);
		pln("Integer.MIN_VALUE: " + Integer.MIN_VALUE);
	}
	
	void pln(String str) {
		System.out.println(str);
	}

	public static void main(String[] args) {
		C5 c = new C5();
		// c.m1();
		c.m2();
		c.m3();
	}
}

