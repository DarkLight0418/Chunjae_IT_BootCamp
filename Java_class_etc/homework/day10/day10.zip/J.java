package day10;

class J {
	void m(int i, int j) {
		System.out.println("J의 m()");
	}
}
class JChild extends J{
	void m(int k, int m) {
		System.out.println("JChild의 m()");
	}
}

