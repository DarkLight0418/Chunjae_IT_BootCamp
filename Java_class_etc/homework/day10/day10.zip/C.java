package day10;

public class C {
	static int i; //1개 
	int j; //2개
	void m() {
		i++;
		j++;
	}
	void show() {
		System.out.println("i: " + i); //?
		System.out.println("j: " + j); //?
	}
}
class CUser{
	public static void main(String args[]) {
		C c1 = new C();
		c1.m();
		C c2 = new C();
		c2.m();
		
		c1.show();
	}
}
