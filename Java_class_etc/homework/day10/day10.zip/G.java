package day10;

public class G {
	String name_$;
	G(){
	}
	void m() {}
}
