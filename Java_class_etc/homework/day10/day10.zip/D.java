package day10;

class D {
	final int I = 10;
	//final D() {}
	final void m(){
		System.out.println("m()");
	} 
}