package day10;

public class K {
	String name;
	int age;
	
	K(){}
	K(String name){ //1
		this.name = name;
	}
	K(int age){//2
		this.age = age;
	}
	int m(byte b) { //3
		System.out.println("3");
		return b;
	}
	void m(String name, int age) { //4
		this.name = name;
		this.age = age;
	}
}
class KChild extends K {
	int age;
	int m(int age) { //5
		System.out.println("5");
		return age;
	}
}

class KUser{
	public static void main(String args[]) {
		//new K("홍길동");
		//new K(25);
		
		KChild k = new KChild();
		byte b = 10;
		k.m(b);
	}
}
