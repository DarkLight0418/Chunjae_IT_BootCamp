package day10;

abstract class E { //추상클래스
	int i;
	E() {} 
	void m1() {	
		System.out.println("m1()");
	}
	abstract void m2(); //추상메소드 
}
class EChild extends E {
	void m2() {
		System.out.println("m2()");
	}
}
class EUser{
	public static void main(String args[]) {
		E e = new EChild();
		System.out.println(e.i);
		e.m1();
		e.m2();
	}
}
