package day10;

public class I {
	String name;
	I(String name){
		super(); //(1)new Object(); 
		this.name = name;
	}
	void m() {
		System.out.println("I의 m()");
	}
}
class IChild extends I {
	String name = "강감찬";
	IChild(){
		super("홍길동"); //(1)new I("홍길동);
	}
	void show() {
		System.out.println(name); 
		System.out.println(super.name); //(2)
		
		m();
		super.m(); //(3) 
	}
	void m() {
		System.out.println("IChild의 m()");
	}
}

class IUser {
	public static void main(String args[]) {
		IChild c = new IChild();
		c.show();
	}
}
