package day10;

class Helper {
	H h;
	Helper(H h){
		this.h = h;
	}
	void work() {
		System.out.println(h.name); //H의 자원 사용  
		h.m(); //H의 자원 사용 
	}
}
