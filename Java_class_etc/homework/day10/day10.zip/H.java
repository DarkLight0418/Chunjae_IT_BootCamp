package day10;

public class H {
	String name;
	H(){
		this("서준서"); //(2)
	}
	H(String name){
		this.name = name; //(1)
		Helper helper = new Helper(this); //(3)
		helper.work();
	}
	void m() {
		System.out.println("Helper의 m()");	
	}
	public static void main(String args[]) {
		new H();
	}
}

