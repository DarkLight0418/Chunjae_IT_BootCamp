package day10;

public class A {
	protected int i;
	protected A() {
		System.out.println("A()");
	}
	protected void m() {
		System.out.println("m()");
	}
}

