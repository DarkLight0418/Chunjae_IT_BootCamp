package day10;

abstract class F {
	//final abstract void m(); //컴파일안되는 이유: final abstract 는 함께 나올 수 없음 
	
	final int I = 10; 
	static final int J = 20; //더 합리적
}
