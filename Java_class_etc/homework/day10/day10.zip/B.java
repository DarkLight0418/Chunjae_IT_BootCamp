package day10;

class B {
	static int i = 10;
	int j = 20; //객체
	B(){
		System.out.println("B()");
	}
	static void m1() {
		System.out.println("m1()");
	}
	void m2() {//객체
		System.out.println("m2()");
	}
}
class BUser{
	public static void main(String args[]) {
		B b = new B();
		System.out.println("b.i: " + b.i);
		b.m1();
		System.out.println("b.i: " + b.j);
		b.m2();
	}
}


