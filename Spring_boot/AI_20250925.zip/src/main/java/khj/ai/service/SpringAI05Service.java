package khj.ai.service;

import java.util.List;

public interface SpringAI05Service {
    List<Double> getEmbeddings(String text);
}
