package khj.ai.service;

public interface SpringAI01Service {
    String getChatResponse(String message);
}
