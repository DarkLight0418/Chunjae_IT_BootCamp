package khj.ai.service;

public interface SpringAI03Service {
    byte[] convertTextToSpeech(String text);
}
