package khj.ai.service;

public interface OpenAiChatService {
    String getChatResponse(String message);
}
