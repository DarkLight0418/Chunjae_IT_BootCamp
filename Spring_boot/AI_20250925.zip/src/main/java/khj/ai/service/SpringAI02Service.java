package khj.ai.service;

public interface SpringAI02Service {
    String generateImage(String prompt);
}
