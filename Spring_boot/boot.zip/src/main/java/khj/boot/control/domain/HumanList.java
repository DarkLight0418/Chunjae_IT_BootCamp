package khj.boot.control.domain;

import lombok.Data;

import java.util.ArrayList;

@Data
public class HumanList {
    private ArrayList<Human> list;
}
