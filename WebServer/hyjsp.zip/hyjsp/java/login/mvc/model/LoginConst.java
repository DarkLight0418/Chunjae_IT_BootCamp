package login.mvc.model;

public class LoginConst {
	public static final int NO_ID = 1;
	public static final int NO_PWD = 2;
	public static final int YES_ID_PWD = 3;
}
