package login.mvc.model;

public class LoginSQL {
	final static String SEL="select * from MEMBER where EMAIL=?";
}
