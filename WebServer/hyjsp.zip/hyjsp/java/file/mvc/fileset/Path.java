package file.mvc.fileset;

public class Path {
	public static final String FILE_STORE = "D:/young/upload/tmp";
}
